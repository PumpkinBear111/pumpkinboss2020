package me.pumpkinbear111.pumpkinboss.events;

import me.pumpkinbear111.pumpkinboss.boss;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;

import static com.sun.tools.doclint.Entity.or;
import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.*;

public class bossDeath implements Listener {

    @EventHandler
    public void event(EntityDeathEvent e) {

        if(bossAlive) {


        if(e.getEntity() == (Entity) bossEntity) {

            if(bossVulnerable == false) {
                bossVulnerable = true;
                boss.setVulnurable(e.getEntity().getLocation()); // Turns the boss to its "vulnerable" state.
            } else { //Boss killed code.

                if(e.getEntity().getKiller().equals(EntityType.PLAYER)) {

                    String killerName = e.getEntity().getKiller().getDisplayName();

                    Bukkit.broadcastMessage(ChatColor.YELLOW+ killerName +ChatColor.RED +"Trick. Or. Treat.");

                }


                ItemStack trophy = new ItemStack(Material.CARVED_PUMPKIN);
                ItemMeta trophyItemMeta = trophy.getItemMeta();
                trophyItemMeta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "" + ChatColor.UNDERLINE + "Pumpkin King Trophy");

                ArrayList lore = new ArrayList();
                lore.add(ChatColor.YELLOW + "The head of the fallen Pumpkin King.");
                lore.add(ChatColor.GRAY + "" + ChatColor.ITALIC + "The head is no longer lit");
                trophyItemMeta.setLore(lore);

                trophy.setItemMeta(trophyItemMeta);

                // Pause

                if(Math.random() >= 0.50) {

                    // Trick

                    Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"A trick this time.");
                    e.getDrops().clear();

                    e.getDrops().add(trophy);
                    e.getDrops().add(new ItemStack(Material.PUMPKIN_SEEDS, 13));
                    e.getDrops().add(new ItemStack(Material.PUMPKIN, 2));

                    Location location = e.getEntity().getLocation();
                    location.getWorld().spawnEntity(location, EntityType.SKELETON);
                    location.getWorld().spawnEntity(location, EntityType.SKELETON);
                    location.getWorld().spawnEntity(location, EntityType.SKELETON);
                    location.getWorld().spawnEntity(location, EntityType.SKELETON);
                    location.getWorld().spawnEntity(location, EntityType.SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.CAVE_SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.CAVE_SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.CAVE_SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.CAVE_SPIDER);
                    location.getWorld().spawnEntity(location, EntityType.ZOMBIE);
                    location.getWorld().spawnEntity(location, EntityType.ZOMBIE);
                    location.getWorld().spawnEntity(location, EntityType.ZOMBIE);

                } else {

                    // Treat

                    Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"A treat this time.");
                    e.getDrops().clear();

                    e.getDrops().add(trophy);
                    e.getDrops().add(new ItemStack(Material.PUMPKIN_SEEDS, 13));
                    e.getDrops().add(new ItemStack(Material.PUMPKIN, 2));
                    e.getDrops().add(new ItemStack(Material.CAKE, 1));
                    e.getDrops().add(new ItemStack(Material.COOKIE, 3));
                    e.getDrops().add(new ItemStack(Material.PUMPKIN_PIE, 7));
                    e.getDrops().add(new ItemStack(Material.DIAMOND, 2));
                    e.getDrops().add(new ItemStack(Material.IRON_INGOT, 4));

                }

            }} else {}



    }}

}
