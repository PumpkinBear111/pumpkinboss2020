package me.pumpkinbear111.pumpkinboss.events;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;

import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossAlive;

public class bed implements Listener {

    @EventHandler
    public void bed(PlayerBedEnterEvent e) {

        if(bossAlive = true) {

            e.setCancelled(true);

            e.getPlayer().sendMessage(ChatColor.RED + "HEY! You cannot sleep during a boss fight.");

        }

    }

}
