package me.pumpkinbear111.pumpkinboss;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;

import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.*;

public class boss {

    public static void startBossFight(Location location) {

        bossVulnerable = false;

        World world = location.getWorld();

        if(bossEntity == null) {} else{
        bossEntity.remove();}

        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "You just made me mad.");
        // Pause
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "Good luck.");
        // Pause

        world.setTime(13000);

        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        //Pause until explosion finishes.

        bossEntity = (LivingEntity) world.spawnEntity(location, EntityType.ZOMBIE);
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        bossEntity.setCustomName(ChatColor.GOLD + "Pumpkin Boss");
        bossEntity.setCustomNameVisible(true);

        bossEntity.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));
        bossEntity.getEquipment().setLeggings(new ItemStack(Material.GOLDEN_LEGGINGS));
        bossEntity.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));

        bossAlive = true;

        bossEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(hp);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_KNOCKBACK).setBaseValue(attackKb);
        bossEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(speed);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(attackDmg);
        bossEntity.setHealth(hp);
        bossEntity.setInvulnerable(false);

    }

    public static void killBoss() {

        bossEntity.setHealth(0);
        bossAlive = false;
        bossVulnerable = false;

    }

    public static void setVulnurable(Location location) {

        World world = location.getWorld();

        bossEntity = (LivingEntity) world.spawnEntity(location, EntityType.ZOMBIE);
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        bossEntity.setCustomName(ChatColor.GOLD + "Pumpkin Boss");
        bossEntity.setCustomNameVisible(true);

        bossEntity.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));
        bossEntity.getEquipment().setLeggings(new ItemStack(Material.GOLDEN_LEGGINGS));
        bossEntity.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));

        bossAlive = true;
        bossVulnerable = true;

        bossEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(2);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_KNOCKBACK).setBaseValue(2);
        bossEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(.4);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(1);
        bossEntity.setInvulnerable(false);

        bossEntity.setHealth(2);



        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"You.");
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"You are too powerful.");
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"Too powerful for me.");
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"Go on. Finish me off.");
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));

    }

}
