package me.pumpkinbear111.pumpkinboss.events;

import me.pumpkinbear111.pumpkinboss.boss;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossAlive;

public class pumpkinBreak implements Listener {

    @EventHandler
    public void event(BlockBreakEvent e) {

        Material blockType = e.getBlock().getType();

        if(blockType.equals(Material.JACK_O_LANTERN)) {

            Location location = e.getBlock().getLocation();

            location.setY(location.getY() + 2);

            boss.startBossFight(location);

            bossAlive = true;

        }

    }

}
