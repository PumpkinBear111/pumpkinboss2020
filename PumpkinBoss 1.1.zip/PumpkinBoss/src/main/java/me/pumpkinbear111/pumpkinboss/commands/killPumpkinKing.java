package me.pumpkinbear111.pumpkinboss.commands;

import me.pumpkinbear111.pumpkinboss.boss;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class killPumpkinKing implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if(sender.hasPermission("pumpkin.kill")) {

            boss.killBoss();

        }

        return false;

    }
}
