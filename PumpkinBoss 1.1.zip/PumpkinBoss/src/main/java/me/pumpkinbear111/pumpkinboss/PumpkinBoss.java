package me.pumpkinbear111.pumpkinboss;

import me.pumpkinbear111.pumpkinboss.commands.killPumpkinKing;
import me.pumpkinbear111.pumpkinboss.commands.summonPumpkinKing;
import me.pumpkinbear111.pumpkinboss.events.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.java.JavaPlugin;

public final class PumpkinBoss extends JavaPlugin {

    public static LivingEntity bossEntity = null;
    public static boolean bossAlive = false;
    public static boolean bossVulnerable = false;

    public static int hp = 200;
    public static double speed = .7;
    public static int attackDmg = 10;
    public static int attackKb = 7;

    @Override
    public void onEnable() {

        // Plugin startup logic

        System.out.println("PumpkinBoss Plugin - Enabled");

        System.out.println("Registering Events");
        getServer().getPluginManager().registerEvents(new bed(), this);
        getServer().getPluginManager().registerEvents(new pumpkinBreak(), this);
        getServer().getPluginManager().registerEvents(new bossDeath(), this);

        System.out.println("Setting command executors.");
        getCommand("killPumpkinKing").setExecutor(new killPumpkinKing());
        getCommand("summonPumpkinKing").setExecutor(new summonPumpkinKing());

        System.out.println("Reading config.yml file");
        getConfig().options().copyDefaults();
        saveDefaultConfig();

        if ( getConfig().getBoolean("useDefaults") == true) {

            System.out.println("useDefaults is set to true, so nothing needs to change.");

        } else {

            System.out.println("useDefaults is set to false, time to change the variables.");

            hp = getConfig().getInt("hp");
            speed = getConfig().getDouble("speed");
            attackDmg = getConfig().getInt("attackDmg");
            attackKb = getConfig().getInt("attackKb");

            System.out.println("Variables have been changed from config.yml");

        }

    }

    @Override
    public void onDisable() {

        // Plugin shutdown logic

        System.out.println("PumpkinBoss Plugin - Disabled");
        bossEntity.remove();
        boolean bossAlive = false;

    }
}
