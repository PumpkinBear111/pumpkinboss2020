package me.pumpkinbear111.pumpkinboss;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;


import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.*;

public class boss {

    public static void startBossFight(World world, Location location) {

        if(bossEntity == null) {} else{
        bossEntity.remove();}

        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "You just made me mad.");
        // Pause
        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "Good luck.");
        // Pause

        world.setTime(13000);

        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        //Pause until explosion finishes.

        bossEntity = (LivingEntity) world.spawnEntity(location, EntityType.ZOMBIE);
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        bossEntity.setCustomName(ChatColor.GOLD + "Pumpkin Boss");
        bossEntity.setCustomNameVisible(true);

        bossEntity.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));
        bossEntity.getEquipment().setLeggings(new ItemStack(Material.GOLDEN_LEGGINGS));
        bossEntity.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));

        bossAlive = true;

        bossEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(200);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_KNOCKBACK).setBaseValue(8);
        bossEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(.7);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(10);
        bossEntity.setHealth(200);
        bossEntity.setInvulnerable(false);

        //bossBar.setProgress(bossEntity.getHealth() / 200);
        //bossBar.setVisible(true);
    }

    public static void killBoss() {

        bossEntity.setHealth(0);
        //bossEntity.remove();
        bossAlive = false;
        //bossBar.setVisible(false);

    }

    public static void setVulnurable(Location location) {

        //bossBar.setVisible(false);

        World world = location.getWorld();

        bossEntity = (LivingEntity) world.spawnEntity(location, EntityType.ZOMBIE);
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        bossEntity.setCustomName(ChatColor.GOLD + "Pumpkin Boss");
        bossEntity.setCustomNameVisible(true);

        bossEntity.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));
        bossEntity.getEquipment().setLeggings(new ItemStack(Material.GOLDEN_LEGGINGS));
        bossEntity.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));

        bossAlive = true;

        bossEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(2);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_KNOCKBACK).setBaseValue(2);
        bossEntity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(.4);
        bossEntity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(1);
        bossEntity.setInvulnerable(false);

        bossEntity.setHealth(2);

        bossAlive = false;

        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"You.");
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));
        //Pause
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"You are too powerful.");
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        //Pause
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"Too powerful for me.");
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.JACK_O_LANTERN));
        //Pause
        Bukkit.broadcastMessage(ChatColor.YELLOW+"Pumpkin King: "+ChatColor.RED +"Go on. Finish me off.");
        bossEntity.getEquipment().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));

    }

    public static void attack1() {

        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "RISE MY ARCHERS! RISE!");

        Location location = bossEntity.getLocation();

        LivingEntity one = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.SKELETON);
        LivingEntity two = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.SKELETON);
        LivingEntity three = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.SKELETON);

        one.setCustomName("Pumpkin King's Archer");
        one.setCustomNameVisible(true);
        one.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        one.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));
        one.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        one.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));

        two.setCustomName("Pumpkin King's Archer");
        two.setCustomNameVisible(true);
        two.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        two.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));
        two.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        two.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));

        three.setCustomName("Pumpkin King's Archer");
        three.setCustomNameVisible(true);
        three.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        three.getEquipment().setChestplate(new ItemStack(Material.GOLDEN_CHESTPLATE));
        three.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        three.getEquipment().setBoots(new ItemStack(Material.GOLDEN_BOOTS));

    }

    public static void attack2() {

        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "You will not be able to defeat my warriors!");

        Location location = bossEntity.getLocation();

        LivingEntity one = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.ZOMBIE);
        LivingEntity two = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.ZOMBIE);
        LivingEntity three = (LivingEntity) location.getWorld().spawnEntity(location ,EntityType.ZOMBIE);

        one.setCustomName("Pumpkin Warrior");
        one.setCustomNameVisible(true);
        one.getEquipment().setItemInMainHand(new ItemStack(Material.IRON_SWORD));
        one.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
        one.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        one.getEquipment().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
        one.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        one.getEquipment().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));

        two.setCustomName("Pumpkin Warrior");
        two.setCustomNameVisible(true);
        two.getEquipment().setItemInMainHand(new ItemStack(Material.IRON_SWORD));
        two.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
        two.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        two.getEquipment().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
        two.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        two.getEquipment().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));

        three.setCustomName("Pumpkin Warrior");
        three.setCustomNameVisible(true);
        three.getEquipment().setItemInMainHand(new ItemStack(Material.IRON_SWORD));
        three.getEquipment().setItemInOffHand(new ItemStack(Material.SHIELD));
        three.getEquipment().setHelmet(new ItemStack(Material.PUMPKIN));
        three.getEquipment().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
        three.getEquipment().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        three.getEquipment().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));

    }

    public static void attack3() {

        Bukkit.broadcastMessage(ChatColor.YELLOW + "Pumpkin King: " + ChatColor.RED + "You go boom now.");

        Location location = bossEntity.getLocation();

        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        // Slight Pause, maybe 10 ticks?
        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);
        location.getWorld().spawnEntity(location, EntityType.PRIMED_TNT);

    }

}
