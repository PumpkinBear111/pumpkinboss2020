package me.pumpkinbear111.pumpkinboss.events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

//import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossBar;

public class playerJoin implements Listener {

    @EventHandler
    public void event(PlayerJoinEvent e) {

        //bossBar.addPlayer(e.getPlayer());

    }

}
