package me.pumpkinbear111.pumpkinboss.events;

import me.pumpkinbear111.pumpkinboss.PumpkinBoss;
import me.pumpkinbear111.pumpkinboss.boss;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.material.MaterialData;

import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossAlive;
import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossEntity;

public class pumpkinBreak implements Listener {

    @EventHandler
    public void event(BlockBreakEvent e) {

        Material blockType = e.getBlock().getType();

        if(blockType.equals(Material.JACK_O_LANTERN)) {

            Player player = e.getPlayer();
            Block block = e.getBlock();
            World world = player.getWorld();
            Location location = block.getLocation();

            location.setY(location.getY() + 2);

            /*
            fallingblock = world.spawnFallingBlock(location, Material.JACK_O_LANTERN.createBlockData());
            fallingblock.setCustomName("Pumpkin Boss");
            fallingblock.setCustomNameVisible(true);
            fallingblock.setGravity(false);
             */



            boss.startBossFight(world, location);

            bossAlive = true;

        }

    }

}
