package me.pumpkinbear111.pumpkinboss;

import me.pumpkinbear111.pumpkinboss.commands.killPumpkinKing;
import me.pumpkinbear111.pumpkinboss.commands.summonPumpkinKing;
import me.pumpkinbear111.pumpkinboss.events.*;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.java.JavaPlugin;

public final class PumpkinBoss extends JavaPlugin {

    //public static BossBar bossBar = Bukkit.createBossBar("Pumpkin King", BarColor.YELLOW, BarStyle.SOLID);
    public static LivingEntity bossEntity = null;
    public static boolean bossAlive = false;

    @Override
    public void onEnable() {
        // Plugin startup logic
        System.out.println("PumpkinBoss Plugin - Enabled");

        getServer().getPluginManager().registerEvents(new bed(), this);
        getServer().getPluginManager().registerEvents(new pumpkinBreak(), this);
        getServer().getPluginManager().registerEvents(new bossDeath(), this);
        getServer().getPluginManager().registerEvents(new bossHurt(), this);
        getServer().getPluginManager().registerEvents(new playerJoin(), this);

        getCommand("killPumpkinKing").setExecutor(new killPumpkinKing());
        getCommand("summonPumpkinKing").setExecutor(new summonPumpkinKing());

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.println("PumpkinBoss Plugin - Disabled");
        bossEntity.remove();
        boolean bossAlive = false;
    }
}
