package me.pumpkinbear111.pumpkinboss.events;

import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

//import static me.pumpkinbear111.pumpkinboss.PumpkinBoss.bossBar;

public class bossHurt implements Listener {

    @EventHandler
    public void event(EntityDamageEvent e) {

        if(e.getEntity().getCustomName().equals(null)) {} else{
        if ( e.getEntity().getCustomName().equals("Pumpkin King") ) {

            LivingEntity livingEntity = (LivingEntity) e.getEntity();

            //Bukkit.broadcastMessage("a");
            //bossBar.setProgress(livingEntity.getHealth() / livingEntity.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue());

        }}

    }

}
